<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); } ?>
<!DOCTYPE html>
<html>
<head>
	<!-- Site Title -->
	<title><?php get_page_clean_title(); ?> &lt; <?php get_site_name(); ?></title>
	<?php get_header(); ?>
	<meta name="robots" content="index, follow" />
    <link href='http://fonts.googleapis.com/css?family=PT+Sans:regular,italic,bold,bolditalic&subset=cyrillic,latin' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/styletext.css" media="all" />
</head>
<body id="<?php get_page_slug(); ?>" >

<div id="maincontainer">
    <div id="menuwrapper">
        <div class="innertube">
            <div id="menu_item" class="menu_div_not_active"><a href="/" class="menu_href_not_active">Главная</a></div>
            <div id="menu_item" class="menu_div_not_active"><a href="/biography" class="menu_href_not_active">Биография</a></div>
            <div id="menu_item" class="menu_div_not_active"><a href="/photos" class="menu_href_not_active">Фотоальбомы</a></div>
            <div id="menu_item" class="menu_div_active"><a href="#" class="menu_href_active">Тексты</a></div>
        </div>
    </div>
    <div id="contentwrapper">
        <div class="innertube">
            <div id="index_text">
                <h2><?php get_page_title() ?></h2><br>
                <?php get_page_content() ?>
            </div>
        </div>
    </div>
    <div id="footer"><<p>
	2006 - 2016 &copy; Все права защищены</p>
	</div>
</div>
<!-- Yandex.Metrika counter -->
<div style="display:none;"><script type="text/javascript">
(function(w, c) {
    (w[c] = w[c] || []).push(function() {
    try {
        w.yaCounter13197826 = new Ya.Metrika({id:13197826, enableAll: true});
    }
    catch(e) { }
});
})(window, "yandex_metrika_callbacks");
</script></div>
<script src="//mc.yandex.ru/metrika/watch.js" type="text/javascript" defer="defer"></script>
<noscript><div><img src="//mc.yandex.ru/watch/13197826" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
</body>
</html>
